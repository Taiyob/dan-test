// src/modules/inspection/inspection.cron.ts
import cron from "node-cron";
import { PrismaClient } from "@prisma/client";
import { AppLogger } from "@/core/logging/logger";
import { computeStatusFromScheduledDate } from "@/utils/ScheduleStatus";

const prisma = new PrismaClient();

export function startInspectionCronJob() {
    AppLogger.info("✅ Inspection cron job initialized.");

    // Run every midnight for testing
    cron.schedule("0 0 * * *", async () => {
        AppLogger.info("🕒 Inspection cron job triggered.");
        try {
            const inspections = await prisma.inspection.findMany({
                where: { deletedAt: null },
                select: { id: true, dueDate: true, status: true },
            });

            let updatedCount = 0;

            for (const insp of inspections) {
                if (!insp.dueDate) continue;
                const newStatus = computeStatusFromScheduledDate(insp.dueDate);
                if (newStatus !== insp.status) {
                    await prisma.inspection.update({
                        where: { id: insp.id },
                        data: { status: newStatus },
                    });
                    updatedCount++;
                }
            }
            AppLogger.info(`✅ Status update complete. ${updatedCount} inspection(s) updated.`);
        } catch (err) {
            AppLogger.error("❌ Error updating inspection statuses", err);
        }
    });
}
