import { BaseService } from "@/core/BaseService";
import { AppError, ConflictError, NotFoundError } from "@/core/errors/AppError";
import { AppLogger } from "@/core/logging/logger";
import { scheduleJob } from "@/services/schedulerService";
import { SESEmailService } from "@/services/SESEmailService";
import { config } from "@/core/config";
import { Inspection, InspectionType, PrismaClient, Reminder, ReminderType } from "@prisma/client";
import { addMinutes, subDays, format } from "date-fns";
import {
  AddInspectionInput,
  InspectionListQuery,
  UpdateInspectionInput,
} from "./inspection.validation";
import { MailtrapEmailService } from "@/services/MailtrapEmailService";
import { ReminderService } from "../Reminder/reminder.service";
//inport {sendEmail} from "@/services/MailTrapEmailService"

export class InspectionService extends BaseService<Inspection> {
  constructor(prisma: PrismaClient) {
    super(prisma, "Inspection", {
      enableSoftDelete: true,
      enableAuditFields: true,
    });
  }

  protected getModel() {
    return this.prisma.inspection;
  }

  //create new inspection, update status and set auto reminders
  async createInspection(data: AddInspectionInput): Promise<Inspection> {
    const { clientId, assetId, dueDate, inspectorIds = [], inspectionType, ...rest } = data;
    console.log("Email Template ID in service:", {data});
    const status = dueDate ? "scheduled" : "not_scheduled";

    const existing = await this.findOne({ clientId, assetId, dueDate });
    if (existing) throw new ConflictError("Inspection already exists");

    const inspection = await this.create({
      clientId,
      assetId,
      dueDate,
      inspectionType,
      status,
      location: rest.location,
      inspectionNotes: rest.inspectionNotes,
    });

    const existingReminder = await this.prisma.reminder.findFirst({
      where: {
        clientId,
        assetId,
        reminderDate: dueDate ? new Date(dueDate) : null,
        isDeleted: false,
      },
    });
    console.log("Existing Reminder Check:", { existingReminder });

    if (!existingReminder) {
      // Assign inspectors to inspection
    if (inspectorIds.length > 0) {
      await this.prisma.inspectionInspectors.createMany({
        data: inspectorIds.map((employeeId) => ({
          inspectionId: inspection.id,
          employeeId,
        })),
      });
    }
    console.log("Reminder already exists for this date — skipping creation");
    // Auto-create Reminder using ReminderService
    if (dueDate && inspectorIds.length > 0) {
    const reminderService = new ReminderService(this.prisma);

    let templateId = data?.emailTemplateId;

    // if (!selectedEmailTemplateId) {
    //   const defaultTemplate = await this.prisma.emailTemplate.findFirst({
    //     where: { isActive: true },
    //     orderBy: { createdAt: "desc" },
    //   });
    //   //selectedEmailTemplateId = defaultTemplate?.id;
    // }

    console.log("Email Template ID for Reminder:", templateId);
    if (!templateId) {
        throw new Error("emailTemplateId is required");
    }

    const defaultTemplate = await this.prisma.emailTemplate.findFirst({
        where: { 
          id: templateId,
        },
        select: { id: true, mailtrapId: true }
    });

    console.log("Using Email Template for Reminder:", defaultTemplate);
    console.log("Using Email Template for Reminder:", defaultTemplate?.id);

    let createdReminder: Reminder | null = null;

    try {
      createdReminder = await reminderService.createReminder({
        clientId,
        assetId,
        reminderType: this.mapToReminderType(inspectionType),
        reminderDate: dueDate.toISOString(),
        notificationMethod: "both",
        additionalNotes: `Auto-generated from Inspection #${inspection.id}`,
        inspectorIds,
        emailTemplateId: defaultTemplate?.id, 
      });

      console.log("Reminder created successfully:", createdReminder.id);
       if (createdReminder) {
      console.log("About to send immediate email for inspection:", inspection.id);
      await this.sendReminderEmails(inspection.id);
      console.log("Immediate email sent successfully");
    }
    } catch (error: any) {
      console.error("Failed during reminder creation or email send:", error);
      AppLogger.error("Reminder + Email flow failed", { error: error.message, stack: error.stack });
    }

   
    // Immediately send 
    // await this.sendReminderEmails(inspection.id); 

    // Schedule reminder 1 day before due date
    // const triggerDate = new Date(dueDate);
    // triggerDate.setDate(triggerDate.getDate() - 1); // 1 day before

    // if (triggerDate > new Date()) {
    //   scheduleJob(
    //     `reminder_email_${reminder.id}`,
    //     triggerDate,
    //     async () => {
    //       try {
    //         await this.sendReminderEmails(inspection.id);
    //         AppLogger.info(`Scheduled reminder email sent for inspection ${inspection.id}`);
    //       } catch (error) {
    //         AppLogger.error(`Scheduled reminder failed`, { inspectionId: inspection.id, error });
    //       }
    //     }
    //   );
    //   AppLogger.info(`Scheduled reminder email for ${format(triggerDate, "yyyy-MM-dd")}`);
    // }
  }   
    }
    return inspection;
}




// async createInspection(data: AddInspectionInput): Promise<Inspection> {
//   const { clientId, assetId, dueDate, inspectorIds = [], inspectionType, emailTemplateId, ...rest } = data;

//   // 1. Duplicate Inspection Check
//   const existingInspection = await this.prisma.inspection.findFirst({
//     where: {
//       clientId,
//       assetId,
//       inspectionType,
//       dueDate: dueDate ? new Date(dueDate) : null,
//       isDeleted: false,
//     },
//   });

//   if (existingInspection) {
//     throw new ConflictError("Inspection already exists for this type and date!");
//   }

//   // 2. Inspection 
//   const inspection = await this.prisma.inspection.create({
//     data: {
//       clientId,
//       assetId,
//       dueDate: dueDate ? new Date(dueDate) : null,
//       inspectionType,
//       status: dueDate ? "scheduled" : "not_scheduled",
//       location: rest.location,
//       inspectionNotes: rest.inspectionNotes,
//     },
//   });

//   // 3. Inspector assign
//   if (inspectorIds.length > 0) {
//     await this.prisma.inspectionInspectors.createMany({
//       data: inspectorIds.map(id => ({
//         inspectionId: inspection.id,
//         employeeId: id,
//       })),
//       skipDuplicates: true,
//     });
//   }

//   // 4. Reminder
//   if (dueDate && emailTemplateId && inspectorIds.length > 0) {
//     const reminderService = new ReminderService(this.prisma);

//     // তারিখ normalize 
//     const normalizedDate = new Date(dueDate);
//     normalizedDate.setHours(0, 0, 0, 0);

//     const startOfDay = new Date(normalizedDate);
//     const endOfDay = new Date(normalizedDate);
//     endOfDay.setHours(23, 59, 59, 999);

//     const existingReminder = await this.prisma.reminder.findFirst({
//       where: {
//         clientId,
//         assetId,
//         reminderDate: {
//           gte: startOfDay,
//           lte: endOfDay,
//         },
//         isDeleted: false,
//       },
//     });

//     if (existingReminder) {
//       console.log("Reminder already exists for this date — skipping creation");
//     } else {
//       await reminderService.createReminder({
//         clientId,
//         assetId,
//         reminderType: "one_time",
//         reminderDate: normalizedDate.toISOString(), 
//         notificationMethod: "both",
//         additionalNotes: `Auto-generated from Inspection #${inspection.id} (${inspectionType})`,
//         inspectorIds,
//         emailTemplateId,
//       });
//       console.log("New single reminder created with all inspectors");
//     }

//     await this.sendReminderEmails(inspection.id);
//   }

//   return inspection;
// }


private mapToReminderType(type: InspectionType): ReminderType {
  const map: Record<string, ReminderType> = {
    daily: "one_time",
    weekly: "weekly",
    monthly: "monthly",
    quarterly: "quarterly",
    semi_annual: "semi_annual",
    annual: "annual",
  };
  return map[type] || "one_time";
}

// inspection.service.ts (replace your existing sendReminderEmails)
private async sendReminderEmails(inspectionId: string): Promise<void> {
  // 1) fetch inspection with its client, asset, and inspectors (join table)
console.log("Sending reminder emails for inspection:", inspectionId);
  const inspection = await this.prisma.inspection.findUnique({
    where: { id: inspectionId },
    include: {
      client: { select: { company: true, email: true } },
      asset: { select: { name: true, serialNo: true, location: true } },
      inspectors: {
        include: {
          employee: { select: { firstName: true, lastName: true, email: true } },
        },
      },
    },
  });

  if (!inspection) {
    AppLogger.warn("Inspection not found", { inspectionId });
    return;
  }

  // 2) find matching reminder separately (because your schema currently doesn't declare reminders[] on Inspection)
  const reminder = await this.prisma.reminder.findFirst({
    where: {
      clientId: inspection.clientId,
      assetId: inspection.assetId,
      isDeleted: false,
      // if dueDate exists, match exactly; otherwise allow null filter (no date)
      ...(inspection.dueDate ? { reminderDate: { equals: inspection.dueDate } } : {}),
    },
    orderBy: { createdAt: "desc" },
    include: { emailTemplate: true },
  });

  if (!reminder) {
    AppLogger.warn("No reminder found for this inspection", { inspectionId });
    return;
  }
console.log("Found reminder for inspection:", reminder);
  // 3) ensure reminder.emailTemplateId exists (or fallback to template on emailTemplate relation)
  const mailtrapTemplateId =  reminder.emailTemplate?.mailtrapId;
 console.log("Mailtrap Template ID:", mailtrapTemplateId);
  if (!mailtrapTemplateId) {
    AppLogger.warn("No mailtrap template id available on reminder or emailTemplate", { reminderId: reminder.id });
    return;
  }

  // 4) collect recipients
  const recipients: string[] = [];
  if (inspection.client?.email) recipients.push(inspection.client.email);
  inspection.inspectors.forEach(i => {
    if (i.employee?.email) recipients.push(i.employee.email);
  });
  const uniqueRecipients = Array.from(new Set(recipients)).filter(Boolean);
  if (uniqueRecipients.length === 0) {
    AppLogger.warn("No recipients for reminder", { inspectionId, reminderId: reminder.id });
    return;
  }

  const dueText = inspection.dueDate ? format(inspection.dueDate, "dd MMM yyyy, hh:mm a") : "Not scheduled";

  const mailtrapService = new MailtrapEmailService({
    token: process.env.MAILTRAP_API_TOKEN!,
    accountId: process.env.MAILTRAP_ACCOUNT_ID!,
    defaultFromEmail: process.env.MAIL_FROM_EMAIL!,
    defaultReplyToEmail: process.env.MAIL_REPLY_TO,
  });

  try {
    console.log(inspection, "Preparing to send reminder email with template:", mailtrapTemplateId);
    const result = await mailtrapService.sendBulkFromTemplate({
      templateId: mailtrapTemplateId,
      recipients: uniqueRecipients,
      templateData: {
        companyName: inspection.client?.company ?? "Client",
        inspectionDate: dueText,
        assetName: inspection.asset?.name ?? inspection.asset?.serialNo ?? "N/A",
        location: inspection.asset?.location ?? inspection.location ?? "N/A",
        inspectorNames: inspection.inspectors
          .map(i => `${i.employee?.firstName ?? ""} ${i.employee?.lastName ?? ""}`.trim())
          .filter(n => n.length > 0)
          .join(", "),
      },
    });

    AppLogger.info("Reminder email sent via dynamic template", {
      inspectionId,
      reminderId: reminder.id,
      templateId: mailtrapTemplateId,
      recipients: uniqueRecipients.length,
    });
  } catch (error: any) {
    AppLogger.error("Failed to send reminder email", {
      inspectionId,
      reminderId: reminder.id,
      templateId: mailtrapTemplateId,
      error: error?.message ?? error,
    });
  }
}


  // private async sendReminderEmails(inspectionId: string): Promise<void> {
  //   const inspection = await this.prisma.inspection.findUnique({
  //     where: { id: inspectionId },
  //     include: {
  //       client: true,
  //       asset: true,
  //       inspectors: { include: { employee: true } },
  //     },
  //   });
  //   if (!inspection) return;

  //   const recipients: string[] = [];
  //   if (inspection.client?.email) recipients.push(inspection.client.email);
  //   for (const i of inspection.inspectors || []) {
  //     if (i.employee?.email) recipients.push(i.employee.email);
  //   }
  //   const uniqueRecipients = Array.from(new Set(recipients)).filter(Boolean);
  //   if (uniqueRecipients.length === 0) return;

  //   const dueText = inspection.dueDate
  //     ? format(inspection.dueDate as unknown as Date, "yyyy-MM-dd HH:mm")
  //     : "N/A";
  //   const subject = "Inspection Reminder";
  //   const html = `
  //     <div style="font-family:Arial,sans-serif;color:#111">
  //       <h2>Inspection Reminder</h2>
  //       <p>Client: <strong>${inspection.client?.company ?? ""}</strong></p>
  //       <p>Asset ID: <strong>${inspection.assetId}</strong></p>
  //       <p>Location: <strong>${inspection.location ?? ""}</strong></p>
  //       <p>Due Date: <strong>${dueText}</strong></p>
  //       <p>Please prepare and complete the scheduled inspection.</p>
  //     </div>
  //   `;
  //   const text = `Inspection Reminder\nClient: ${inspection.client?.company ?? ""}\nAsset ID: ${inspection.assetId}\nLocation: ${inspection.location ?? ""}\nDue Date: ${dueText}`;

  //   const ses = new SESEmailService({
  //     region: config.email.awsRegion,
  //     awsAccessKeyId: config.email.awsAccessKeyId,
  //     awsSecretAccessKey: config.email.awsSecretAccessKey,
  //     defaultFromEmail: config.email.defaultFromEmail,
  //     defaultReplyToEmail: config.email.defaultReplyToEmail,
  //   });

  //   const results = await ses.sendBulkEmails(uniqueRecipients, {
  //     from: config.email.defaultFromEmail,
  //     fromName: config.email.defaultFromName,
  //     subject,
  //     html,
  //     text,
  //     replyTo: config.email.defaultReplyToEmail,
  //   });
  //   const ok = results.filter(r => r.success).length;
  //   const fail = results.filter(r => !r.success).length;
  //   AppLogger.info("Inspection reminder emails processed", { inspectionId, ok, fail });
  // }

  //get inspections

//   private async sendReminderEmails(inspectionId: string): Promise<void> {
//   const inspection = await this.prisma.inspection.findUnique({
//     where: { id: inspectionId },
//     include: {
//       client: true,
//       asset: true,
//       inspectors: { include: { employee: true } },
//     },
//   });
//   if (!inspection) return;

//   const recipients: string[] = [];
//   if (inspection.client?.email) recipients.push(inspection.client.email);
//   for (const i of inspection.inspectors || []) {
//     if (i.employee?.email) recipients.push(i.employee.email);
//   }
//   const uniqueRecipients = Array.from(new Set(recipients)).filter(Boolean);
//   if (uniqueRecipients.length === 0) return;

//   const dueText = inspection.dueDate
//     ? format(inspection.dueDate as unknown as Date, "yyyy-MM-dd HH:mm")
//     : "N/A";

//   // Mailtrap
//   // const mailtrapService = new MailtrapEmailService();
//   // try {
//   //   const result = await mailtrapService.sendBulkFromTemplate({
//   //     templateId: "f43d9c53-0da5-49fd-becd-9fba7320fec4", 
//   //     recipients: uniqueRecipients,
//   //     templateData: {
//   //       firstName: inspection.client?.company || "Client",
//   //       inspectionDate: dueText,
//   //       assetId: inspection.assetId,
//   //       location: inspection.location || "N/A",
//   //     },
//   //   });

//   //   AppLogger.info("Reminder emails sent via Mailtrap", {
//   //     inspectionId,
//   //     success: result.success,
//   //     failed: result.failed,
//   //   });
//   // } catch (error) {
//   //   AppLogger.error("Failed to send reminder emails", { inspectionId, error });
//   // }

//   const mailtrapService = new MailtrapEmailService({
//     token: process.env.MAILTRAP_API_TOKEN!,
//     defaultFromEmail: process.env.MAIL_FROM_EMAIL,
//     defaultReplyToEmail: process.env.MAIL_REPLY_TO,
//     accountId: process.env.MAILTRAP_ACCOUNT_ID!,
// });

//   const result =  await mailtrapService.sendBulkFromTemplate({
//     //templateId: "f43d9c53-0da5-49fd-becd-9fba7320fec4",
//     //templateId: "6a414390-2d44-4d22-8035-5f8640876d4d",
//     templateId: "6a41d390-2d44-4d22-8035-5f6640376d4d",
//     recipients: uniqueRecipients,
//     templateData: {
//       firstName: inspection.client?.company || "Client",
//       inspectionDate: dueText,
//       assetId: inspection.assetId,
//       location: inspection.location || "N/A",
//     },
//   });

//   console.log("Mailtrap Reminder Result:", result);
// }

  async getInspections(query: InspectionListQuery) {
    const {
      page,
      limit,
      search,
      status,
      sortBy = "createdAt",
      sortOrder = "desc",
      ...rest
    } = query;

    let filters: any = {};
    if (search)
      filters.OR = [
        { location: { contains: search, mode: "insensitive" } },
        { inspectionNotes: { contains: search, mode: "insensitive" } },
      ];
    if (status) filters.status = status;

    const result = await this.findMany(
      filters,
      { page, limit, offset: (page - 1) * limit },
      { [sortBy]: sortOrder },
      {
        client: true,
        asset: true,
        inspectors: { include: { employee: true } },
      }
    );

    AppLogger.info(`Inspections found: ${result.data.length}`);
    return result;
  }

  async getInspectionById(id: string): Promise<Inspection | null> {
    const inspection = await this.prisma.inspection.findUnique({
      where: { id },
      include: {
        client: true,
        asset: true,
        inspectors: { include: { employee: true } },
      },
    });
    if (!inspection) throw new NotFoundError("Inspection");
    return inspection;
  }

  async updateInspection(
    id: string,
    data: UpdateInspectionInput
  ): Promise<Inspection> {
    const exists = await this.exists({ id });
    if (!exists) throw new NotFoundError("Inspection");

    const { inspectorIds, ...updateData } = data;
    const updated = await this.updateById(id, updateData);

    if (inspectorIds) {
      await this.prisma.inspectionInspectors.deleteMany({
        where: { inspectionId: id },
      });
      await this.prisma.inspectionInspectors.createMany({
        data: inspectorIds.map((employeeId) => ({
          inspectionId: id,
          employeeId,
        })),
      });
      AppLogger.info(
        `Updated ${inspectorIds.length} inspector(s) for inspection ${id}`
      );
    }

    return updated;
  }

  async deleteInspection(id: string): Promise<Inspection> {
    const exists = await this.exists({ id });
    if (!exists) throw new NotFoundError("Inspection");
    return await this.deleteById(id);
  }
}
